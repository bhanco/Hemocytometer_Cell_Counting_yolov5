
Hemocytometer Cell Count - v10 No augmentations or changes
==============================

This dataset was exported via roboflow.ai on October 27, 2021 at 3:29 PM GMT

It includes 36 images.
Cells are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)

No image augmentation techniques were applied.


