
Cropped Cell Count - v2 roboflow_cropped_1024_v2
==============================

This dataset was exported via roboflow.ai on October 28, 2021 at 2:09 PM GMT

It includes 244 images.
Cells are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 1024x1024 (Stretch)

The following augmentation was applied to create 10 versions of each source image:
* Equal probability of one of the following 90-degree rotations: none, clockwise, counter-clockwise, upside-down
* Random brigthness adjustment of between -5 and +5 percent


